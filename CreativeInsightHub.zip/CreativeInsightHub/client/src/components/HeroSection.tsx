import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Database, ShieldCheck, DollarSign } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-background to-primary/5">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <motion.div 
            className="md:w-1/2 md:pr-8 mb-10 md:mb-0"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-4">
              Turn Unused Software Licenses Into <span className="text-primary">Revenue</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              SoftSell helps businesses recover costs from unused software licenses. 
              Quick valuations, secure transactions, and hassle-free payments.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Button size="lg" className="px-8">
                Get a Quote
              </Button>
              <Button size="lg" variant="outline" className="px-8">
                Sell My Licenses
              </Button>
            </div>
          </motion.div>
          
          <motion.div 
            className="md:w-1/2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="bg-card rounded-xl shadow-xl p-6 border">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-primary/10 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <Database className="h-8 w-8 text-primary mb-2" />
                  <h3 className="font-semibold text-lg">Verify</h3>
                  <p className="text-sm text-muted-foreground">License validation</p>
                </div>
                <div className="bg-primary/10 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <ShieldCheck className="h-8 w-8 text-primary mb-2" />
                  <h3 className="font-semibold text-lg">Secure</h3>
                  <p className="text-sm text-muted-foreground">Safe transactions</p>
                </div>
                <div className="bg-primary/10 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <DollarSign className="h-8 w-8 text-primary mb-2" />
                  <h3 className="font-semibold text-lg">Value</h3>
                  <p className="text-sm text-muted-foreground">Maximize returns</p>
                </div>
                <div className="bg-gradient-to-r from-primary/80 to-primary rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <h3 className="font-semibold text-lg text-primary-foreground">Join 1000+</h3>
                  <p className="text-sm text-primary-foreground/90">Satisfied sellers</p>
                </div>
              </div>
              
              <div className="rounded-lg bg-muted p-4 mb-4">
                <div className="mb-2 text-sm font-medium">Recent Transactions</div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Adobe Creative Cloud</span>
                    <span className="font-medium">$380</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Microsoft Office Pro</span>
                    <span className="font-medium">$215</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">Autodesk Maya</span>
                    <span className="font-medium">$590</span>
                  </div>
                </div>
              </div>
              
              <div className="text-center text-sm text-muted-foreground mt-4">
                Average payout within 48 hours of verification
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
