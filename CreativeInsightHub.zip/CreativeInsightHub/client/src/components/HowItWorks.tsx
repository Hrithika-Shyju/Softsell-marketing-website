import { motion } from "framer-motion";
import { Upload, CheckCircle, CreditCard } from "lucide-react";

const steps = [
  {
    icon: <Upload className="h-10 w-10" />,
    title: "Upload License",
    description: "Securely upload your license key or certificate. We support all major software vendors and formats."
  },
  {
    icon: <CheckCircle className="h-10 w-10" />,
    title: "Get Valuation",
    description: "Our system instantly analyzes your license and provides a competitive market valuation."
  },
  {
    icon: <CreditCard className="h-10 w-10" />,
    title: "Get Paid",
    description: "Accept the offer and receive payment via your preferred method within 48 hours."
  }
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-16 bg-background border-t">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">How It Works</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our streamlined process makes selling your unused software licenses quick and hassle-free.
          </p>
        </div>
        
        <div className="relative">
          {/* Progress Line */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-1 bg-muted -translate-y-1/2 z-0"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 relative z-10">
            {steps.map((step, index) => (
              <motion.div 
                key={index}
                className={`bg-card rounded-xl shadow-sm border p-6 text-center ${index === 1 ? 'md:mt-12' : ''}`}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="rounded-full bg-primary text-primary-foreground w-16 h-16 flex items-center justify-center mx-auto mb-6">
                  {step.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
