import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  MessageSquare, 
  X, 
  Send,
  Bot
} from "lucide-react";

type Message = {
  text: string;
  isBot: boolean;
};

const suggestedQuestions = [
  "How does the license valuation work?",
  "What software licenses do you buy?",
  "How long does the process take?",
  "Is my data secure?"
];

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { 
      text: "Hi there! I'm your SoftSell assistant. How can I help you today?", 
      isBot: true 
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const toggleChat = () => {
    setIsOpen(!isOpen);
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };
  
  const handleSendMessage = () => {
    if (inputValue.trim() === "") return;
    
    // Add user message
    setMessages(prev => [...prev, { text: inputValue, isBot: false }]);
    setInputValue("");
    
    // Simulate bot response
    setTimeout(() => {
      let response = "I'm sorry, I don't have information on that specific topic. Would you like to talk to a human representative?";
      
      // Simple keyword matching for demo purposes
      const lowercaseInput = inputValue.toLowerCase();
      
      if (lowercaseInput.includes("valuation") || lowercaseInput.includes("worth")) {
        response = "Our valuation process analyzes current market rates, software version, license type, and remaining term. We typically offer 40-70% of retail value for transferable licenses.";
      } else if (lowercaseInput.includes("time") || lowercaseInput.includes("long") || lowercaseInput.includes("process")) {
        response = "The entire process usually takes 2-4 business days. Verification takes 24-48 hours, and payment is processed within 24 hours after verification.";
      } else if (lowercaseInput.includes("software") || lowercaseInput.includes("licenses") || lowercaseInput.includes("buy")) {
        response = "We buy licenses from major vendors like Microsoft, Adobe, Oracle, Autodesk, VMware, and many others. Both perpetual and subscription licenses can often be resold.";
      } else if (lowercaseInput.includes("secure") || lowercaseInput.includes("security") || lowercaseInput.includes("data")) {
        response = "Yes, your data is secure with us. We use bank-level encryption for all transactions and are compliant with major data protection regulations like GDPR and CCPA.";
      }
      
      setMessages(prev => [...prev, { text: response, isBot: true }]);
    }, 1000);
  };
  
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };
  
  const handleSuggestedQuestion = (question: string) => {
    setMessages(prev => [...prev, { text: question, isBot: false }]);
    
    // Simulate bot response for suggested questions
    setTimeout(() => {
      let response = "";
      
      if (question.includes("valuation")) {
        response = "Our valuation process analyzes current market rates, software version, license type, and remaining term. We typically offer 40-70% of retail value for transferable licenses.";
      } else if (question.includes("take")) {
        response = "The entire process usually takes 2-4 business days. Verification takes 24-48 hours, and payment is processed within 24 hours after verification.";
      } else if (question.includes("licenses do you buy")) {
        response = "We buy licenses from major vendors like Microsoft, Adobe, Oracle, Autodesk, VMware, and many others. Both perpetual and subscription licenses can often be resold.";
      } else if (question.includes("secure")) {
        response = "Yes, your data is secure with us. We use bank-level encryption for all transactions and are compliant with major data protection regulations like GDPR and CCPA.";
      }
      
      setMessages(prev => [...prev, { text: response, isBot: true }]);
    }, 1000);
  };
  
  useEffect(() => {
    // Scroll to bottom when messages change
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            className="bg-card rounded-xl shadow-xl w-80 sm:w-96 overflow-hidden border mb-4"
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.9 }}
          >
            <div className="bg-primary p-4 text-primary-foreground flex justify-between items-center">
              <div className="flex items-center">
                <Bot className="mr-2 h-5 w-5" />
                <span className="font-medium">SoftSell Assistant</span>
              </div>
              <button 
                onClick={toggleChat} 
                className="text-primary-foreground hover:text-primary-foreground/80 transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="p-4 h-80 overflow-y-auto flex flex-col space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={`flex items-start ${message.isBot ? "" : "justify-end"}`}>
                  {message.isBot && (
                    <div className="rounded-full bg-primary/10 w-8 h-8 flex items-center justify-center text-primary mr-2 mt-1">
                      <Bot className="h-4 w-4" />
                    </div>
                  )}
                  <div className={`rounded-lg p-3 max-w-[85%] ${
                    message.isBot ? "bg-muted" : "bg-primary text-primary-foreground"
                  }`}>
                    <p className="text-sm">{message.text}</p>
                  </div>
                  {!message.isBot && (
                    <div className="rounded-full bg-muted w-8 h-8 flex items-center justify-center text-muted-foreground ml-2 mt-1">
                      <span className="text-xs">You</span>
                    </div>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            
            <div className="p-4 border-t">
              <div className="mb-2 text-xs text-muted-foreground">Suggested questions:</div>
              <div className="flex flex-wrap gap-2 mb-4">
                {suggestedQuestions.map((question, index) => (
                  <button 
                    key={index}
                    onClick={() => handleSuggestedQuestion(question)}
                    className="text-xs bg-muted hover:bg-muted/70 transition-colors px-3 py-1 rounded-full"
                  >
                    {question}
                  </button>
                ))}
              </div>
              
              <div className="flex">
                <Input
                  value={inputValue}
                  onChange={handleInputChange}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your question..."
                  className="rounded-r-none"
                />
                <Button 
                  onClick={handleSendMessage}
                  className="rounded-l-none"
                  variant="default"
                  size="icon"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      <motion.button
        onClick={toggleChat}
        className="w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <MessageSquare className="h-6 w-6" />
      </motion.button>
    </div>
  );
}
