# SoftSell - Software License Resale Marketplace

A responsive single-page marketing website for 'SoftSell', a fictional software resale startup, built with React and Tailwind CSS.

## Features Implemented

- **Responsive Design**: Mobile-first approach ensuring the website looks great on all devices
- **Modern UI Components**: Built with React and styled with Tailwind CSS
- **Interactive Elements**: 
  - Animated sections using Framer Motion
  - Interactive chat widget with simulated AI responses
  - Form validation using React Hook Form and Zod
- **Dark/Light Mode**: Theme toggle with system preference detection
- **SEO Optimized**: Proper meta tags and semantic HTML

## Design Choices

- **Color Scheme**: Consistent color palette with primary brand color and appropriate contrast
- **Typography**: Clean, readable font hierarchy
- **Animation**: Subtle animations to enhance user experience without being distracting
- **Component Architecture**: Modular components for better maintainability

## Tech Stack

- **Frontend**: React with TypeScript
- **Styling**: Tailwind CSS
- **Animation**: Framer Motion
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite
- **Server**: Express.js

## Project Structure

```
├── client           # Frontend React application
│   ├── src
│   │   ├── components  # UI components
│   │   ├── hooks       # Custom React hooks
│   │   ├── lib         # Utility functions
│   │   └── pages       # Page components
├── server           # Backend Express server
├── shared           # Shared types and schemas
```

## Local Development

1. Clone the repository
2. Install dependencies: `npm install`
3. Start the development server: `npm run dev`
4. Open http://localhost:5000 in your browser

## License

MIT