export default function Footer() {
  return (
    <footer className="bg-muted py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-primary/50 rounded-lg flex items-center justify-center">
                <span className="text-xl">💾</span>
              </div>
              <span className="text-xl font-bold">Soft<span className="text-primary">Sell</span></span>
            </div>
            <p className="text-muted-foreground mb-4">
              The trusted marketplace for software license resale. 
              Turning unused software into revenue since 2018.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">How It Works</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Why Choose Us</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Testimonials</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Resources</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Blog</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Software Guide</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Compliance</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <ul className="space-y-2">
              <li className="text-muted-foreground">contact@softsell.com</li>
              <li className="text-muted-foreground">+1 (555) 123-4567</li>
              <li className="text-muted-foreground">123 Tech Street, San Francisco, CA 94107</li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-border text-muted-foreground text-sm flex flex-col md:flex-row justify-between items-center">
          <div>© 2023 SoftSell. All rights reserved.</div>
          <div className="mt-4 md:mt-0">
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors mr-4">Privacy Policy</a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors mr-4">Terms of Service</a>
            <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
