import { motion } from "framer-motion";
import { 
  Banknote, 
  ShieldCheck, 
  Clock, 
  UserCheck 
} from "lucide-react";

const reasons = [
  {
    icon: <Banknote className="h-10 w-10" />,
    title: "Competitive Pricing",
    description: "Get the best value for your software licenses with our market-based pricing algorithm."
  },
  {
    icon: <ShieldCheck className="h-10 w-10" />,
    title: "Secure Transactions",
    description: "Our platform ensures all license transfers are secure, legal, and fully compliant."
  },
  {
    icon: <Clock className="h-10 w-10" />,
    title: "Fast Payouts",
    description: "Receive payment within 48 hours of verification, with multiple payout options."
  },
  {
    icon: <UserCheck className="h-10 w-10" />,
    title: "Dedicated Support",
    description: "Our expert team guides you through every step of the selling process."
  }
];

export default function WhyChooseUs() {
  return (
    <section id="why-choose-us" className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Why Choose SoftSell</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            We've helped thousands of businesses recover value from their unused software licenses.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, index) => (
            <motion.div 
              key={index}
              className="bg-card rounded-xl shadow-sm border p-6 h-full"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="rounded-full bg-primary/10 p-4 w-16 h-16 flex items-center justify-center mb-4 text-primary">
                {reason.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{reason.title}</h3>
              <p className="text-muted-foreground">{reason.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
