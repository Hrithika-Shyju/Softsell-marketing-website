import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import ThemeToggle from "./ThemeToggle";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMenuOpen(false);
    }
  };

  return (
    <nav className="sticky top-0 z-40 w-full bg-background/90 backdrop-blur-sm border-b">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-primary to-primary-foreground rounded-lg flex items-center justify-center">
              <span className="text-xl">💾</span>
            </div>
            <span className="text-xl font-bold">Soft<span className="text-primary">Sell</span></span>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('how-it-works')} 
              className="font-medium text-foreground/80 hover:text-primary transition-colors"
            >
              How It Works
            </button>
            <button 
              onClick={() => scrollToSection('why-choose-us')} 
              className="font-medium text-foreground/80 hover:text-primary transition-colors"
            >
              Why Choose Us
            </button>
            <button 
              onClick={() => scrollToSection('testimonials')} 
              className="font-medium text-foreground/80 hover:text-primary transition-colors"
            >
              Testimonials
            </button>
            <button 
              onClick={() => scrollToSection('contact')} 
              className="font-medium text-foreground/80 hover:text-primary transition-colors"
            >
              Contact
            </button>
          </div>
          
          {/* CTA and Theme Toggle */}
          <div className="hidden md:flex items-center space-x-4">
            <ThemeToggle />
            <Button variant="outline" className="font-medium">Log In</Button>
            <Button className="font-medium">Get Started</Button>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-4">
            <ThemeToggle />
            <button 
              onClick={toggleMenu}
              className="text-foreground focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden pt-4 pb-4 border-t mt-2">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('how-it-works')} 
                className="font-medium text-foreground/80 hover:text-primary transition-colors py-2"
              >
                How It Works
              </button>
              <button 
                onClick={() => scrollToSection('why-choose-us')} 
                className="font-medium text-foreground/80 hover:text-primary transition-colors py-2"
              >
                Why Choose Us
              </button>
              <button 
                onClick={() => scrollToSection('testimonials')} 
                className="font-medium text-foreground/80 hover:text-primary transition-colors py-2"
              >
                Testimonials
              </button>
              <button 
                onClick={() => scrollToSection('contact')} 
                className="font-medium text-foreground/80 hover:text-primary transition-colors py-2"
              >
                Contact
              </button>
              <div className="flex space-x-4 pt-2">
                <Button variant="outline" className="font-medium" size="sm">Log In</Button>
                <Button className="font-medium" size="sm">Get Started</Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
